package cs3500.marblesolitaire.model.hw02;

/**
 * Represents a state of a Marble Solitaire state.
 */
public enum CellState {
  ILLEGAL, MARBLE, EMPTY
}
